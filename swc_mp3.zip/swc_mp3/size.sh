#!/bin/bash

cd obj
total_sum=0
sum1=0
sum2=0
sum3=0


for i in *.o; do
  echo $i
  array=(`objdump -h $i | grep -e .text`)
  size1=${array[2]}
  echo code size: $size1
  let "dec = 0x$size1"
  sum1=$((sum1+dec))

  array=(`objdump -h $i | grep -e .data`)
  size2=${array[2]}
  echo data size: $size2
  let "dec = 0x$size2"
  sum2=$((sum2+dec))

  array=(`objdump -h $i | grep -e .bss`)
  size3=${array[2]}
  echo bss  size: $size3
  let "dec = 0x$size3"
  sum3=$((sum3+dec))
  echo 
done;

echo "total code: $sum1"
echo "total data: $sum2"
echo "total  bss: $sum3"

echo "total all: $((sum1+sum2+sum3))"


