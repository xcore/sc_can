#include <math.h>
#include <stdio.h>

int main(void){

  double i;
  double expo;

  expo = 1./3.;
  double sum;

  for(i = 0; i < 10; i+=1){

    sum += pow(i, expo);

  }

  printf("%.10f\n", sum/10);

  sum = 0;
  for(i = 10; i < 100; i+=1){
    sum += pow(i, expo);
  }
   
  printf("%.10f\n", sum/90);

  sum = 0;
  for(i = 100; i < 1000; i+=1){
    sum += pow(i, expo);
  }
   
  printf("%.10f\n", sum/900);

  sum = 0;
  for(i = 1000; i < 10000; i+=1){
    sum += pow(i, expo);
  }
   
  printf("%.10f\n", sum/9000);


}


