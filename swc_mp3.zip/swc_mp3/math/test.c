#include <math.h>
#include <stdio.h>
#include <string.h>

#ifdef XCC2
#  include "../common/include/common.h"
#endif

#include "../core0/include/mad0.h"

/*
 * table for requantization
 *
 * rq_table[x].mantissa * 2^(rq_table[x].exponent) = x^(4/3)
*/
static
struct fixedfloat {
  unsigned mantissa  : 27;
  unsigned short exponent :  5;
} const rq_table[8207] = {
  #include "rq_table.dat"
};

struct mydouble {
//  unsigned long mantissa : 52;
  unsigned mantissa0 : 32;
  unsigned mantissa1 : 20;
  unsigned short exponent : 11;
  unsigned sign : 1;
};

#ifdef NEWTON
double newton_raphson(unsigned a, double init);
#endif
#ifdef SHIFTING
unsigned shifting_3rd_root(unsigned);
#endif

double toDouble(struct fixedfloat arg){

  struct mydouble _d;
  double *d = (double *)&_d;

  _d.mantissa0 = arg.mantissa << 24;
  _d.mantissa1 = arg.mantissa >> 8;
  _d.sign = 0;
  _d.exponent = 1023;
  *d -= 1;
  _d.exponent += arg.exponent;

  return (*d);

}

double toFraction(struct fixedfloat arg){

  struct mydouble _d;
  double *d = (double *)&_d;

  _d.mantissa0 = arg.mantissa << 24;
  _d.mantissa1 = arg.mantissa >> 8;
  _d.sign = 0;
  _d.exponent = 1023;
  *d -= 1;

  return (*d);

}

int iterations_needed = 0;

int mylog = 0;

struct fixedfloat toFixed(double arg){

  struct fixedfloat ret;
  struct mydouble *tmp = (struct mydouble *)&arg;

  unsigned *ptr = (unsigned *) &arg;
  unsigned *ptr2 = (unsigned *) &ret;

//  if(mylog)
//    printf("converting to fixed: %x%x--\n", ptr[1], ptr[0]);

  ret.exponent = 0;
  
  while(arg >= 0.5){
//    if(mylog)
//      printf("%.16f ", arg);
    ret.exponent +=1;
    tmp->exponent -=1;
  }

//  if(mylog){
//    printf("%.16f\n", arg);
//    printf("converting to fixed: %x%x----\n", ptr[1], ptr[0]);
//    printf("tmp->mantissa1: %x tmp->mantissa0: %x--%f\n", tmp->mantissa1, tmp->mantissa0, arg);
//  }
 
  arg +=1;
  
  ret.mantissa = (tmp->mantissa0 >> 24) | ((unsigned)tmp->mantissa1 << 8);//need only 27 bits not 28 bits. need to think this through again?!

//  if(mylog) 
//    printf("tmp->mantissa1: %x tmp->mantissa0: %x----%f\n", tmp->mantissa1, tmp->mantissa0, arg);
  if(((tmp->mantissa0 >> 22) & 3) == 3){//rounding up!
//    if(mylog)
//      printf("converting to fixed (rounding): %x ", ptr2[0]);
    ret.mantissa += 1;
//    if(mylog)
//      printf("to %x \n", ptr2[0]);
  }

  if(ret.mantissa == 0 && ret.exponent != 0){
    ret.mantissa = 1 << 26;
    ret.exponent += 1;
  }

//  if(mylog)
//    printf("converting to fixed (final): %x\n", ptr2[0]);

  return ret;

}

#ifdef XCC2
unsigned readTime();
#else
unsigned readTime(){
  return 0;
}
#endif


#ifdef XCC2
void main1(){
#else
int main(){
#endif

  struct fixedfloat res2, res8;
  double res1, res7;

  int i;
  
  unsigned *ptr2 = (unsigned *)&res8;

  char lookup[1024], shifting[1024];

  int errors = 0;

  int time1, time2, timeMax = 0;

  for(i = 0; i < 8207; i+=1){

    res2 = rq_table[i];

    res1 = toDouble(res2);

    sprintf(lookup, "/* %4d */ { MAD_F(0x%08x) /* %.9f */, %2d },\n", i, res2.mantissa, toFraction(res2), res2.exponent);//correct


    time1 = readTime();
    
    *ptr2 = shifting_3rd_root(i);

    time2 = readTime();

    if((time2 - time1) > timeMax) //overflow?
      timeMax = time2 - time1;
    printf("Time elapsed: %d\n", time2 - time1);
    sprintf(shifting, "/* %4d */ { MAD_F(0x%08x) /* %.9f */, %2d },\n", i, res8.mantissa, toFraction(res8), res8.exponent);

    res7 = toDouble(res8);

    if(strcmp(lookup, shifting) != 0){

      printf("error:%6d, i: %6d, lookup %6d.%09d, shifting: %6d.%09d\n" , errors, i, (int)toDouble(res2), (int)((toDouble(res2) - (int)toDouble(res2))*1000000000), (int)toDouble(res8), (int)((toDouble(res8) - (int)toDouble(res8))*1000000000));

      printf("lookup::: %sshifting: %s", lookup, shifting);

      errors+=1;
 
    }
    else
    {
#ifdef LOG
        printf("lookup: %sshift:: %s\n", lookup, shifting);
#endif
      
    }

    printf("max time: %d\n", timeMax);
  }


  printf("total errors: %d\n", errors);

}

#if 0
#ifdef NEWTON

#define f(x, a) (x*x*x - a)
#define fder(x) (3*x*x)

double newton_raphson(unsigned a, double x0)
{
  printf("a:%d x0:%10.10f\n",a, x0);
	INT Max_iterations = 1000, iteration_no;
	double x1;

  double E2 = 0.00000000745;// 1.0/(2^27) //this can be dropped to 0.00000002 but the same number of iterations are needed anyways.
  double fx;
  int tmp; 

	x1 = x0;
	iteration_no = 1;

	while(1)
	{
		x0 = x1;
    fx = f(x0, a);
    if(fabs(fx) < E2)
      break;
		x1 = x0 - (fx/fder(x0));
		iteration_no++;
	}
		

  printf("iteration number: %d\n", iteration_no)	;


  if(iteration_no > iterations_needed)  {
    iterations_needed = iteration_no;
    printf("new iteration number:%d\n", iteration_no);
    scanf("%d", &tmp);
  }

  return (x0*a);

}

#endif
#endif

