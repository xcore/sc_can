//////////////////////////////////////////////////////////////////////////////////
//     Name: Sulaiman AbuKharmeh,                                               //
//////////////////////////////////////////////////////////////////////////////////
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

double f(double x);
double fder(double x);

double init[] = {1.4809683218, 3.6745847907, 7.9435562448, 17.1196477068 };//this is the average of x^(1/3) for the intervals 0-9, 10-99, 100-999, 1000-9999

#define f(x, a) (x*x*x - a)
#define fder(x) (3*x*x)

int main(int argc, char **argv)
{

  unsigned a;	
	double E2;
	int max_iterations = 1000, iteration_no;
  E2 = 0.0000000005;
	int choice = 0;
	double x0, x1;

  for(int i =1; i < argc; i++) {

    printf("%s\n", argv[i]);
    a = atoi(argv[i]);
      

 
  //x0 based on a:
  if(a < 10)
    x0 = init[0];
  else if(a < 100)
    x0 = init[1];
  else if(a < 1000)
    x0 = init[2];
  else if(a < 10000)
    x0 = init[3];
  else{
    printf("a must be < 10000\nexiting\n");
    continue;
  }
    

	x1 = x0;
	iteration_no = 1;

	if(f(x0, a) != 0 && fder(x0) != 0)
	{
		printf("\n Here are the iterations for Newton-Raphson method:\n");
		printf("\n\n_________________________________________________________________\n");
		printf("    i       Xi              Xi+1                 f(Xi)      \n");
		printf("_________________________________________________________________\n");
		
		do
		{
			x0 = x1;
			x1 = x0 - (f(x0, a)/fder(x0));
			printf("%5d %17.10f %15.10f %25.15f\n",iteration_no,x0,x1,f(x0, a));
			iteration_no++;
		}while(fabs(f(x0, a)) >= E2 && iteration_no <= max_iterations);
			
		if( fabs(f(x0, a)) >= E2 && iteration_no > max_iterations)
			printf("\nThe root not found after %d iterations.\n",max_iterations);
		else if(fabs(f(x0, a)) < E2)
			printf("\nThe root is: %10.10f found after %d iterations.\n\n\n",x0*a,iteration_no-1);
		else 
			printf("\nThe program is not working properly.");
	}
}
}

		
