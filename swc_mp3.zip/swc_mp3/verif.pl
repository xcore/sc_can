#!/usr/bin/perl
use warnings;
use strict;
use Cwd;
use File::Copy;

use File::Basename;

my $break;

sub main
{
  $break = 0;

  verif($_[0]);
 
  if($break != 0)
  {
    print("ERRRRORRRRR: Unexpected error...\n");
  }
  else{
    print("Success....\n");
  }


  return;

}



sub verif{
  
  my $file_name;
  my @raw_data;
  my $test_name;
  my $return;
	my $base;

  $file_name="test_list.txt";
  open(TESTS, $file_name) || die("Could not open file!");
  @raw_data=<TESTS>;

  my $past = time();
  
  my $count = 0;

  foreach $test_name (@raw_data){

    $test_name = substr($test_name, 0, -1);#remove new line

		$base = basename($test_name);

    if(cmd("make all MP3_FILE_NAME=$test_name.mp3 PCM_FILE_NAME=$test_name.pcm OUT_FILE_NAME=$test_name.xe TEST_NAME=$base") != 0){
      return;
    }

    if(cmd("minimad 0<$test_name.mp3 1>$test_name.pcm.gold") != 0){
      return;
    }
 
    if(cmd("xsim $test_name.xe") != 0){
      return;
    }

		cmd("chmod 700 $test_name.pcm");

    if(cmd("diff -b $test_name.pcm.gold $test_name.pcm") != 0){
      return;
    }
    
    $count += 1;

    if(defined($_[0]) && $_[0] == $count){
      last;
    }
   
  }

  my $diff = time() - $past;
  my $mDiff = int($diff / 60);
  my $sDiff = sprintf("%02d", $diff - 60 * $mDiff);
  print "total time check = $mDiff\:$sDiff\n";

 
}

sub cmd{

  my $past   = time();

  print("$_[0]\n");

  $break = system($_[0]);

  my $diff = time() - $past;
  my $mDiff = int($diff / 60);
  my $sDiff = sprintf("%02d", $diff - 60 * $mDiff);
  print "time check = $mDiff\:$sDiff\n";

  return $break;

}

main(shift, shift);
