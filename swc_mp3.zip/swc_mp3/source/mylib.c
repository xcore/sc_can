/**
* Module:  xmos_mp3
* File:    mylib.c
*
* The copyrights, all other intellectual and industrial
* property rights are retained by XMOS and/or its licensors.
* Terms and conditions covering the use of this code can
* be found in the Xmos End User License Agreement.
*
* Copyright XMOS Ltd 2009
*
* In the case where this code is a modification of existing code
* under a separate license, the separate license terms are shown
* below. The modifications to the code are still covered by the
* copyright notice above.
*
**/

#if 1 
#include <syscall.h>
#include <limits.h>
#include "mp3.h" 

int printchar(char value)
{
  unsigned char tmp[1];
  tmp[0] = value;
  return _write(FD_STDOUT, tmp, 1);
}

static void reverse_array(char buf[], unsigned size)
{
  int begin = 0;
  int end = size - 1;
  int tmp;
  for (;begin < end;begin++,end--) {
    tmp = buf[begin];
    buf[begin] = buf[end];
    buf[end] = tmp;
  }
}

static int printuint_base_aux(unsigned n, int base)
{ static const char digits[] = "0123456789ABCDEF";
  char buf[CHAR_BIT * sizeof(unsigned)];
  int i = 0;
  while (n > 0) {
    int next = n / base;
    int cur  = n % base;
    buf[i] = digits[cur];
    i += 1;
    n = next;
  }
  reverse_array(buf, i);
  return _write(FD_STDOUT, buf, i);
}

static int printuint_base(unsigned n, int base)
{ if (n == 0)
    return printchar('0');
  else
    return printuint_base_aux(n, base);
}

int mystrlen(const char s[])
{ int i = 0;
  while(s[i] != '\0')
    i++;
  return i;
}

int _printstr(const char s[]){ 

	int len = mystrlen(s);
#ifndef SIM
	return xlog_debug(s);
#else
	return _write(FD_STDOUT, s, len);
#endif

}

int _printhex(unsigned n)
{ return printuint_base(n, 16);
}

int myprintint(unsigned n)
{ return printuint_base(n, 10);
}
char buf[2];

int myfputc(char c, int f){

	char buf[2];
	buf[0] = c;
	buf[1] = '\0';
	return _write(f, buf, 1);
}



#endif
